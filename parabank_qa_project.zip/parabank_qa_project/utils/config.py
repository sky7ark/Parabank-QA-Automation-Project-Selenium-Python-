# Put your test credentials here.
# You can manually register on https://parabank.parasoft.com and use those credentials.
# Example (may or may not work on the live demo):
TEST_USERNAME = "sky7ark"
TEST_PASSWORD = "Pera.sr.007"

# If you prefer headless execution (no browser window), set HEADLESS = True
HEADLESS = False
