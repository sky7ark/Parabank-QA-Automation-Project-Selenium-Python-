import pytest
import time
from selenium.webdriver.common.by import By
from utils.browser_setup import get_driver
from utils.config import TEST_USERNAME, TEST_PASSWORD, HEADLESS
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.open_account_page import OpenAccountPage

HOME_URL = "https://parabank.parasoft.com"

@pytest.fixture
def driver():
    driver = get_driver(headless=HEADLESS)
    driver.get(HOME_URL)
    yield driver
    driver.quit()

def test_login_and_open_account(driver):
    # Attempt login
    login = LoginPage(driver)
    login.login(TEST_USERNAME, TEST_PASSWORD)
    time.sleep(2)

    # Check if login succeeded by presence of 'Accounts Overview' or Open New Account link
    home = HomePage(driver)
    if not home.is_element_present(HomePage.OPEN_NEW_ACCOUNT_LINK):
        pytest.skip("Login failed or Open New Account link not present. Please register a test user and update utils/config.py")

    # Go to Open New Account
    home.go_to_open_account()
    time.sleep(2)

    open_page = OpenAccountPage(driver)
    open_page.open_new_account()
    time.sleep(2)
    success = open_page.get_success_message()
    assert "account" in success.lower() or "congratulations" in success.lower(), f"Unexpected success message: {success}"

    # Logout
    home.logout()
    time.sleep(1)
