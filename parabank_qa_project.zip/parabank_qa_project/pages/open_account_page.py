from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class OpenAccountPage(BasePage):
    ACCOUNT_TYPE = (By.ID, "type")             # select element
    FROM_ACCOUNT = (By.ID, "fromAccountId")    # select element
    OPEN_BUTTON = (By.XPATH, "//input[@value='Open New Account']")
    SUCCESS_TEXT = (By.XPATH, "//p[contains(text(),'Congratulations') or contains(text(),'Account')]")

    def open_new_account(self):
        # default selections should be valid; just click Open
        self.click(self.OPEN_BUTTON)

    def get_success_message(self):
        # Wait until the success message appears, then return text
        self.wait.until(lambda d: len(d.find_elements(*self.SUCCESS_TEXT)) > 0)
        return self.get_text(self.SUCCESS_TEXT)

