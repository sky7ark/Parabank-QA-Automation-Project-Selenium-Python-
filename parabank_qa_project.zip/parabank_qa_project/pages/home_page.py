from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class HomePage(BasePage):
    OPEN_NEW_ACCOUNT_LINK = (By.LINK_TEXT, "Open New Account")
    LOGOUT_LINK = (By.LINK_TEXT, "Log Out")

    def go_to_open_account(self):
        self.click(self.OPEN_NEW_ACCOUNT_LINK)

    def logout(self):
        self.click(self.LOGOUT_LINK)
