# Parabank QA Automation (Selenium + Python)

Demo Selenium + pytest project for the Parabank demo site:
https://parabank.parasoft.com

## Overview
This project demonstrates:
- Selenium automation with Python (Selenium 4)
- Pytest test structure and fixtures
- Page Object Model (POM)
- WebDriver Manager to auto-install chromedriver

The main automated test:
- Log into Parabank
- Navigate to "Open New Account"
- Create a new account
- Verify success and logout

## Requirements
- Python 3.10+ (you have 3.13.2 — good)
- Google Chrome
- Recommended: create and activate a virtual environment

## Install
```bash
python -m venv .venv
# Windows
.\.venv\Scripts\activate
# macOS / Linux
# source .venv/bin/activate

pip install -r requirements.txt
```

## Configure
Edit `utils/config.py` to set `TEST_USERNAME` and `TEST_PASSWORD`. The Parabank demo sometimes has sample users such as `john` / `demo`, but if those do not work, register on the site manually and set credentials here.

## Run tests
```bash
pytest -q
```

To generate an HTML report (if pytest-html installed):
```bash
pytest --html=reports/report.html --self-contained-html
```

## Notes
- Demo sites change over time; you may need to tweak locators in `pages/*` if the site markup changes.
- This project is designed for demonstration and learning; expand with more tests for a stronger portfolio.
